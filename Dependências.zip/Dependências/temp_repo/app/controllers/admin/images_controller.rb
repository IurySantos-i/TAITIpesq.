class Admin::ImagesController < Admin::ApplicationController
  def index
  end
end
