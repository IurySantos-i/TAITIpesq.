class Complaint < ActiveRecord::Base
end
