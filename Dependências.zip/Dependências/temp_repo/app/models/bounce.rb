class Bounce < ActiveRecord::Base
end
