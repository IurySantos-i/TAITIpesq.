class CallCampaign < ActiveRecord::Base
  has_one :action_page
end
