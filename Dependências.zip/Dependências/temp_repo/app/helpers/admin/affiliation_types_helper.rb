module Admin::AffiliationTypesHelper
end
