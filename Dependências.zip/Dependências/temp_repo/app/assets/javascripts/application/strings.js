window.App = window.App || {};

window.App.Strings = {
  successfulEmailSubmission: "Thanks for subscribing, you're awesome! Check your email for a confirmation link.",
  failedEmailSubmission: "We're sorry, something went wrong with your subscription. Please try again later.",
  addressLookupFailed: "We were unable to find a zip+4 for the address you entered.  Make sure you *only* entered your street address (without your city and state).  Please check and try again.",
};
