InvisibleCaptcha.setup do |config|
  # Allow cacheing of forms that use invisible captchas.
  config.timestamp_enabled = false
end
