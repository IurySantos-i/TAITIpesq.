# Be sure to restart your server when you modify this file.

Actioncenter::Application.config.session_store :active_record_store, key: '_actioncenter_session'
