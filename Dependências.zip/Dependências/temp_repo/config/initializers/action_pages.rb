Actioncenter::Application.config.action_pages_email_text = File.read(Rails.root.join('config','action_email.md'))
