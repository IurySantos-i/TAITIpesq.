FactoryGirl.define do
  factory :affiliation_type do
    name "Student"
  end
end
