FactoryGirl.define do
  factory :category do
    title "Free Speech"
  end
end
