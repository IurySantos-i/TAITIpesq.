FactoryGirl.define do
  factory :affiliation do
    institution
    affiliation_type
  end
end
